#!/bin/sh

rm /data/data/com.termux/files/home/.termux/termux.properties
mv termux-properties /data/data/com.termux/files/home/.termux/termux.properties
rm /data/data/com.termux/files/usr/etc/bash.bashrc
mv bash.bashrc /data/data/com.termux/files/usr/etc/bash.bashrc
source /data/data/com.termux/files/usr/etc/bash.bash
mv zshrc .zshrc && mv .zshrc ~/
termux-change-repo  && termux-reload-settings && termux-setup-storage
auug && pkg install root-repo x11-repo git curl wget zsh android-tools apt-file zip unzip python-pip sqlite -y
